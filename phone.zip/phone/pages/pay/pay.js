var app = getApp();
Page({
  data:{
    allMoney:1,
    sec:3
  },
  onShow:function(){
    var waitPayGoods = app.globalData.waitPayGoods;
    var allMoney = 0;
    for (var i = 0; i < waitPayGoods.length;i++){
      allMoney = waitPayGoods[i].num * waitPayGoods[i].price + allMoney;
    }
    this.setData({
      allMoney: allMoney
    })
  },
  payment(){
    this.setData({
      allMoney:0
    })
    var sec = this.data.sec
    var that = this;
    var url = "../index/index";
    var timer = setInterval(function () {
      sec--;
      that.setData({
        sec: sec
      })
      if (sec<= 0) {
        wx.switchTab ({
          url: url
        })
        clearInterval(timer)
      }
    }, 1000)
    var payedGoods = app.globalData.payedGoods;
    var waitPayGoods = app.globalData.waitPayGoods;
    for (var i = 0; i < waitPayGoods.length;i++){
      payedGoods.push(waitPayGoods[i]);
      waitPayGoods.splice(i,1);
      i--;
    }
  }


})