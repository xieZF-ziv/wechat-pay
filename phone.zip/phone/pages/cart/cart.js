var app = getApp();
Page({
  data:{
    arr:[],
    allMoney:0,
    allChecked:true,
    num:0
  },
  onShow:function(){
    // 全局变量
    var msg = app.globalData.msg;
    var isAllChecked = true;
    var allMoney = 0;
    for(var i=0;i<msg.length;i++){
      if(!msg[i].checked){
        isAllChecked=false;
      }
      if (msg[i].checked){
        allMoney = msg[i].price * msg[i].num + allMoney
      }
      this.setData({
        allChecked: isAllChecked,
        num:msg.length
      })
    }
    this.setData({
      arr:msg,
      allMoney:allMoney
    })
  },
  // 单个选择
  isChecked(e){
    // 全局变量
    var msg = app.globalData.msg;
    var index = e.target.id;
    msg[index].checked = !msg[index].checked;
    this.onShow();
  },
  // 全选按钮
  choiceAll(){
    // 全局变量
    var msg = app.globalData.msg;
    var allChecked = this.data.allChecked;
    allChecked = !allChecked
    if (allChecked){
      for(var i=0; i<msg.length;i++){
        msg[i].checked=true
      }
    }else{
      for (var i = 0; i < msg.length; i++) {
        msg[i].checked = false
      }
    }
    this.setData({
      allChecked : !allChecked
    })
    this.onShow();
  },
  // 购买操作
  enterBuy(){
    // 全局变量
    var msg = app.globalData.msg;
    var waitPayGoods = app.globalData.waitPayGoods;

    for(var i=0;i<msg.length;i++){
      if (msg[i].checked){
        waitPayGoods.push(msg[i])
        msg.splice(i, 1)
        i--;
      }
    }
    var url = "../pay/pay"
    wx.navigateTo({
      url: url
    })
  }
 
})