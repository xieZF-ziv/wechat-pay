var app = getApp();
Page({
  data:{
    num:0
  },
  onShow:function(){
    var payedGoods = app.globalData.payedGoods;
    var num = 0;
    for (var i = 0; i < payedGoods.length;i++){
      num++;
      this.setData({
        num:num
      })
    }
  },
  enterPayed(){
    var url = "../payed/payed"
    wx.navigateTo({
      url: url
    })
  },
  enterWaitPay(){
    var url = "../pay/pay";
    wx.navigateTo({
      url: url
    })
  }

})