Page({
  data: {
    imgSrc: [
      'http://img02.tooopen.com/images/20150928/tooopen_sy_143912755726.jpg',
      'http://img06.tooopen.com/images/20160818/tooopen_sy_175866434296.jpg',
      'http://img06.tooopen.com/images/20160818/tooopen_sy_175833047715.jpg'
    ],
    indicatorDots: true,
    autoplay: true,
    interval: 2000,
    duration: 500,
    arr: []
  },
  onLoad:function(){
    var that = this;
    var url = "http://pbkt7f9eb.bkt.clouddn.com/wechat_goods.json";
    // 拿数据
    wx.request({
      url: url, 
      data: {
        x: '',
        y: ''
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        var data = res.data;
        var arr = [];
        for(var i=0;i<data.lengthl;i++){
          arr.push(data[i])
        }
        that.setData({
          arr:data
        })
      }
    })
   
  },
  enterDetail(e){
    var title = e.currentTarget.dataset.title;
    var price = e.currentTarget.dataset.price;
    var imgSrc = e.currentTarget.dataset.imgsrc;
    var goods = {
      imgSrc:imgSrc,
      title:title,
      price:price
    }
    // 设置传递
    var url="../detail/detail?goods=";
    wx.navigateTo({
      url: url + JSON.stringify(goods)
    })
  }
})