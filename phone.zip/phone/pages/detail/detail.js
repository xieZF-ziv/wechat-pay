var app = getApp();
Page({
  data:{
    imgSrc:"",
    price:0,
    title:"",
    count:1,
    num:0,
    allCount:0
  },
  onLoad:function(option){
    var goods = JSON.parse(option.goods);
    this.setData({
      imgSrc: goods.imgSrc,
      title: goods.title,
      price: goods.price
    });
    // 全局变量
    var msg = app.globalData.msg;
    var allCount = this.data.allCount;
    for (var i=0;i<msg.length;i++){
      allCount += msg[i].num;
    }
    this.setData({
      allCount:allCount
    })
  },
  del(){
    var count = this.data.count;
    if(count<=1){
      count=1
    }else(
      count--
    )
    this.setData({
      count:count
    })

  },
  add(){
    var count = this.data.count;
    count++;
    this.setData({
      count: count
    })
  },
  // 加入购物车按钮
  addCart(){
    var imgSrc = this.data.imgSrc;
    var title = this.data.title;
    var price = this.data.price;
    var count = this.data.count;
    var num = this.data.num;
    var allCount = this.data.allCount;
    this.setData({
      num: count + num,
      allCount: allCount + count
    })
    // 全局变量
    var msg = app.globalData.msg;
    // 要传递的参数
    var params = {
      imgSrc: imgSrc,
      title: title,
      price: price,
      num: num+count,
      checked:true
    }
    // 判断是否有相同数据
    var isTrue = false;
    for (var i = 0; i < msg.length; i++) {
      if (imgSrc == msg[i].imgSrc) {
        isTrue = true
        msg[i].num = msg[i].num + count;
        break;
      }
    }
    if (!isTrue) {
      msg.push(params)
    }
  },
  enterCart(){
    var url = "../cart/cart";
    wx.switchTab ({
      url:url
    })
  }
})