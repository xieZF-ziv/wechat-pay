var app = getApp();
Page({
  data:{
    item:0,
    arr:[]
  },
  onShow:function(){
    var payedGoods = app.globalData.payedGoods;
    var arr = []
    for (var i = 0;i<payedGoods.length;i++){
      arr.push(payedGoods[i])
    }
    this.setData({
      item: payedGoods.length,
      arr:arr
    })
  }
})